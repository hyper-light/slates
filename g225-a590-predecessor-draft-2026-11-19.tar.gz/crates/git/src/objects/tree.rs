//! A tree object (A-590): its entries, each `<mode> SP <name> NUL <id>`, parsed as git's `decode_tree_entry` reads them
//! (tree-walk.c, `parse_mode` in object.h), written back byte for byte, ordered as git orders them, and checked as
//! git's `fsck_tree` (fsck.c) checks them.
//!
//! The mode is kept as written as well as read: git reads octal digits into an `unsigned int` and keeps the low 16
//! bits, and a mode written with a leading zero (`040000`), which git once wrote and fsck now warns of
//! (`zeroPaddedFilemode`), is served as written.

use core::cmp::Ordering;

use super::fsck::{FsckId, Report, Strictness};
use super::headers::{ObjectRefused, Refusal};
use super::{ObjectFormat, dotgit};
use crate::{Admission, PastAdmission};

/// Format: a mode's file-type bits (`S_IFMT`).
const S_IFMT: u16 = 0o170000;
/// Format: a directory's type (`S_IFDIR`).
const S_IFDIR: u16 = 0o040000;
/// Format: a symbolic link's type (`S_IFLNK`).
const S_IFLNK: u16 = 0o120000;
/// Format: the modes git writes and fsck accepts (fsck.c `fsck_tree`): a regular file 0644 or 0755, a symbolic link, a
/// directory and a submodule's commit (`S_IFGITLINK`).
const STANDARD_MODES: [u16; 5] = [0o100644, 0o100755, S_IFLNK, S_IFDIR, 0o160000];
/// Format: the nonstandard mode git wrote "early on when we honored the full set of mode bits" (fsck.c): accepted unless
/// the check is strict.
const OLD_GROUP_WRITABLE: u16 = 0o100664;
/// Format: the longest name fsck accepts without a warning (`max_tree_entry_len`, fsck.c, `fsck.largePathname`'s
/// default), in bytes.
const LARGE_PATHNAME: usize = 4096;

/// One entry of a tree, as written.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Entry<'a> {
  /// The mode's octal digits as written (`100644`, or a zero-padded `040000`).
  pub mode_text: &'a [u8],
  /// The mode git reads from them (`parse_mode`: the low 16 bits).
  pub mode: u16,
  /// The name.
  pub name: &'a [u8],
  /// The object id, the repository's hash length of raw bytes.
  pub id: &'a [u8],
}

impl Entry<'_> {
  /// Whether the entry is a directory (`S_ISDIR`), which orders as if its name ended with `/`.
  pub fn is_dir(&self) -> bool {
    self.mode & S_IFMT == S_IFDIR
  }

  /// Whether the entry is a symbolic link (`S_ISLNK`).
  pub fn is_symlink(&self) -> bool {
    self.mode & S_IFMT == S_IFLNK
  }

  /// Writes the entry as it was read.
  pub fn write(&self, out: &mut impl crate::out::Out) {
    out.put(self.mode_text);
    out.put(b" ");
    out.put(self.name);
    out.put(b"\0");
    out.put(self.id);
  }
}

/// git's order of two entries (`base_name_compare`, tree.c): their names byte by byte, a directory's as if it ended
/// with `/`.
pub fn compare(a: &Entry<'_>, b: &Entry<'_>) -> Ordering {
  let shared = a.name.len().min(b.name.len());
  let (Some(a_head), Some(b_head)) = (a.name.get(..shared), b.name.get(..shared)) else {
    return Ordering::Equal;
  };
  a_head.cmp(b_head).then_with(|| {
    let next = |entry: &Entry<'_>| {
      entry
        .name
        .get(shared)
        .copied()
        .unwrap_or(if entry.is_dir() { b'/' } else { b'\0' })
    };
    next(a).cmp(&next(b))
  })
}

/// A tree: its entries in the order written.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Tree<'a> {
  /// The entries.
  entries: Vec<Entry<'a>>,
}

/// Decodes the entry at `from` (git's `decode_tree_entry`): the entry and where the next begins.
fn entry_at(bytes: &[u8], from: usize, format: ObjectFormat) -> Result<(Entry<'_>, usize), ObjectRefused> {
  let refused = |at: usize, refusal: Refusal| ObjectRefused { at, refusal };
  let rest = bytes.get(from..).unwrap_or_default();
  let raw = format.raw_len();
  // Its entries must end in a NUL and an id: the check git makes before reading one ("too-short tree object").
  let ends_well = rest
    .len()
    .checked_sub(raw.saturating_add(1))
    .and_then(|nul| rest.get(nul))
    == Some(&b'\0');
  if rest.len() < raw.saturating_add(3) || !ends_well {
    return Err(refused(from, Refusal::TooShortTree));
  }
  let space = rest
    .iter()
    .position(|byte| !(b'0'..=b'7').contains(byte))
    .filter(|at| *at > 0 && rest.get(*at) == Some(&b' '))
    .ok_or_else(|| refused(from, Refusal::MalformedMode))?;
  let mode_text = rest.get(..space).unwrap_or_default();
  // `parse_mode`: octal digits into an `unsigned int`, wrapping as C's does, its low 16 bits kept.
  let wide = mode_text.iter().fold(0_u32, |mode, digit| {
    mode.wrapping_shl(3).wrapping_add(u32::from(digit.wrapping_sub(b'0')))
  });
  let mode = u16::try_from(wide & u32::from(u16::MAX)).unwrap_or(u16::MAX);
  let name_from = space.saturating_add(1);
  let name_len = rest
    .get(name_from..)
    .and_then(|tail| tail.iter().position(|byte| *byte == b'\0'))
    .ok_or_else(|| refused(from, Refusal::TooShortTree))?;
  if name_len == 0 {
    return Err(refused(from.saturating_add(name_from), Refusal::EmptyName));
  }
  let id_from = name_from.saturating_add(name_len).saturating_add(1);
  let next = id_from.saturating_add(raw);
  let (Some(name), Some(id)) = (
    rest.get(name_from..name_from.saturating_add(name_len)),
    rest.get(id_from..next),
  ) else {
    return Err(refused(from, Refusal::TruncatedEntry));
  };
  Ok((
    Entry {
      mode_text,
      mode,
      name,
      id,
    },
    from.saturating_add(next),
  ))
}

/// Every entry of `bytes` in order, or the first refusal.
fn entries(bytes: &[u8], format: ObjectFormat) -> impl Iterator<Item = Result<Entry<'_>, ObjectRefused>> {
  let mut from = 0;
  let mut stopped = false;
  core::iter::from_fn(move || {
    if stopped || from >= bytes.len() {
      return None;
    }
    match entry_at(bytes, from, format) {
      Ok((entry, next)) => {
        from = next;
        Some(Ok(entry))
      }
      Err(refused) => {
        stopped = true;
        Some(Err(refused))
      }
    }
  })
}

impl<'a> Tree<'a> {
  /// Parses `bytes`, a tree of `format`, charging its entries to `admission` before any is kept.
  pub fn parse(bytes: &'a [u8], format: ObjectFormat, admission: &mut Admission) -> Result<Self, ObjectRefused> {
    let mut count = 0_usize;
    for entry in entries(bytes, format) {
      entry?;
      count = count.saturating_add(1);
    }
    admission
      .charge_items::<Entry<'a>>(count)
      .map_err(|past| ObjectRefused {
        at: 0,
        refusal: Refusal::PastAdmission(past),
      })?;
    let mut kept = Vec::with_capacity(count);
    for entry in entries(bytes, format) {
      kept.push(entry?);
    }
    Ok(Self { entries: kept })
  }

  /// The entries in the order written.
  pub fn entries(&self) -> &[Entry<'a>] {
    &self.entries
  }

  /// Writes the tree as it was read.
  pub fn write(&self, out: &mut impl crate::out::Out) {
    for entry in &self.entries {
      entry.write(out);
    }
  }
}

/// What [`fsck`] found in a tree, besides its report: the ids of the `.gitmodules` and `.gitattributes` blobs it names,
/// which git checks as blobs once it has them (`gitmodules_found`, `gitattributes_found`).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Checked<'a> {
  /// The findings, in git's order.
  pub report: Report,
  /// The ids of the blobs named `.gitmodules` (in any spelling HFS+ or NTFS resolves) that are not symbolic links.
  pub gitmodules: Vec<&'a [u8]>,
  /// The ids of the blobs named `.gitattributes` that are not symbolic links.
  pub gitattributes: Vec<&'a [u8]>,
}

/// What `verify_ordered` (fsck.c) says of two neighbouring entries.
#[derive(PartialEq, Eq)]
enum Order {
  /// In order.
  Ordered,
  /// Out of order (`TREE_UNORDERED`).
  Unordered,
  /// The same name twice, as a file and as a directory included (`TREE_HAS_DUPS`).
  Duplicate,
}

/// `is_less_than_slash`: a byte that sorts between the NUL and `/`.
fn below_slash(byte: u8) -> bool {
  byte != b'\0' && byte < b'/'
}

/// Keeps `item` on `kept`, its room charged to `admission` first.
fn keep<T>(kept: &mut Vec<T>, item: T, admission: &mut Admission) -> Result<(), PastAdmission> {
  admission.charge_items::<T>(1)?;
  kept.push(item);
  Ok(())
}

/// `verify_ordered` (fsck.c): orders entry `b` after `a`, keeping on `candidates` the files whose name a later
/// directory could repeat (`foo` before `foo.bar` before `foo/`), each charged to `admission`.
fn verify_ordered<'a>(
  a: &Entry<'a>,
  b: &Entry<'a>,
  candidates: &mut Vec<&'a [u8]>,
  admission: &mut Admission,
) -> Result<Order, PastAdmission> {
  let shared = a.name.len().min(b.name.len());
  let head = |name: &'a [u8]| name.get(..shared).unwrap_or_default();
  match head(a.name).cmp(head(b.name)) {
    Ordering::Less => return Ok(Order::Ordered),
    Ordering::Greater => return Ok(Order::Unordered),
    Ordering::Equal => {}
  }
  let (mut c1, mut c2) = (
    a.name.get(shared).copied().unwrap_or(b'\0'),
    b.name.get(shared).copied().unwrap_or(b'\0'),
  );
  if c1 == b'\0' && c2 == b'\0' {
    return Ok(Order::Duplicate);
  }
  if c1 == b'\0' && a.is_dir() {
    c1 = b'/';
  }
  if c2 == b'\0' && b.is_dir() {
    c2 = b'/';
  }
  if c1 == b'\0' && below_slash(c2) {
    keep(candidates, a.name, admission)?;
  } else if c2 == b'/' && below_slash(c1) {
    while let Some(file) = candidates.pop() {
      let Some(rest) = b.name.strip_prefix(file) else {
        continue;
      };
      match rest.first() {
        None => return Ok(Order::Duplicate),
        Some(next) if below_slash(*next) => {
          candidates.push(file);
          break;
        }
        Some(_) => {}
      }
    }
  }
  Ok(if c1 < c2 { Order::Ordered } else { Order::Unordered })
}

/// The flags `fsck_tree` raises over a whole tree, reported after its walk in this order.
#[derive(Default)]
struct Flags {
  /// `nullSha1`.
  null_id: bool,
  /// `fullPathname`.
  full_path: bool,
  /// `emptyName`.
  empty_name: bool,
  /// `hasDot`.
  dot: bool,
  /// `hasDotdot`.
  dotdot: bool,
  /// `hasDotgit`.
  dotgit: bool,
  /// `zeroPaddedFilemode`.
  zero_padded: bool,
  /// `badFilemode`.
  bad_mode: bool,
  /// `duplicateEntries`.
  duplicate: bool,
  /// `treeNotSorted`.
  unsorted: bool,
  /// `largePathname`.
  large_name: bool,
}

/// Checks `bytes`, a tree of `format`, as git's `fsck_tree` does, under `strictness`; what the check keeps beside the
/// bytes (the names a later directory could repeat, the ids of special blobs) is charged to `admission` as it grows.
pub fn fsck<'a>(
  bytes: &'a [u8],
  format: ObjectFormat,
  strictness: Strictness,
  admission: &mut Admission,
) -> Result<Checked<'a>, PastAdmission> {
  let mut checked = Checked {
    report: Report::new(strictness),
    gitmodules: Vec::new(),
    gitattributes: Vec::new(),
  };
  let mut walk = entries(bytes, format);
  // The first entry is decoded before the walk (`init_tree_desc_gently`): a tree whose first entry cannot be read is
  // `badTree` and nothing more.
  let mut current = match walk.next() {
    None => return Ok(checked),
    Some(Err(_)) => {
      checked.report.report(FsckId::BadTree);
      return Ok(checked);
    }
    Some(Ok(entry)) => entry,
  };
  let mut flags = Flags::default();
  let mut previous: Option<Entry<'_>> = None;
  let mut candidates = Vec::new();
  loop {
    check_entry(&current, format, &mut flags, (&mut checked, admission))?;
    // The next entry is decoded before this one's mode and order are judged (`update_tree_entry_gently`): one that
    // cannot be read is `badTree`, and the walk ends with this entry's mode and order unjudged.
    let next = match walk.next() {
      Some(Err(_)) => {
        checked.report.report(FsckId::BadTree);
        break;
      }
      next => next.and_then(Result::ok),
    };
    let standard = STANDARD_MODES.contains(&current.mode)
      || (current.mode == OLD_GROUP_WRITABLE && strictness == Strictness::Default);
    flags.bad_mode |= !standard;
    if let Some(previous) = &previous {
      match verify_ordered(previous, &current, &mut candidates, admission)? {
        Order::Unordered => flags.unsorted = true,
        Order::Duplicate => flags.duplicate = true,
        Order::Ordered => {}
      }
    }
    previous = Some(current);
    match next {
      Some(entry) => current = entry,
      None => break,
    }
  }
  report_flags(&flags, &mut checked.report);
  Ok(checked)
}

/// The name checks `fsck_tree` makes of each entry as it reaches it, before it decodes the next.
fn check_entry<'a>(
  entry: &Entry<'a>,
  format: ObjectFormat,
  flags: &mut Flags,
  (checked, admission): (&mut Checked<'a>, &mut Admission),
) -> Result<(), PastAdmission> {
  let name = entry.name;
  flags.null_id |= entry.id.iter().all(|byte| *byte == 0) && entry.id.len() == format.raw_len();
  flags.full_path |= name.contains(&b'/');
  flags.empty_name |= name.is_empty();
  flags.dot |= name == b".";
  flags.dotdot |= name == b"..";
  flags.dotgit |= dotgit::dotgit(name);
  flags.zero_padded |= entry.mode_text.first() == Some(&b'0');
  flags.large_name |= name.len() > LARGE_PATHNAME;
  if dotgit::dotgitmodules(name) {
    gitmodules(entry, checked, admission)?;
  }
  if dotgit::dotgitattributes(name) {
    if entry.is_symlink() {
      checked.report.report(FsckId::GitattributesSymlink);
    } else {
      keep(&mut checked.gitattributes, entry.id, admission)?;
    }
  }
  if entry.is_symlink() {
    if dotgit::dotgitignore(name) {
      checked.report.report(FsckId::GitignoreSymlink);
    }
    if dotgit::dotmailmap(name) {
      checked.report.report(FsckId::MailmapSymlink);
    }
  }
  // NTFS reads a backslash as a separator: each part after one is checked as a name of its own.
  for (index, _) in name.iter().enumerate().filter(|(_, byte)| **byte == b'\\') {
    let after = name.get(index.saturating_add(1)..).unwrap_or_default();
    flags.dotgit |= dotgit::ntfs_dotgit(after);
    if dotgit::ntfs_dotgitmodules(after) {
      gitmodules(entry, checked, admission)?;
    }
  }
  Ok(())
}

/// A `.gitmodules` entry: a symbolic link is `gitmodulesSymlink`, a blob is kept to be checked as one.
fn gitmodules<'a>(
  entry: &Entry<'a>,
  checked: &mut Checked<'a>,
  admission: &mut Admission,
) -> Result<(), PastAdmission> {
  if entry.is_symlink() {
    checked.report.report(FsckId::GitmodulesSymlink);
    Ok(())
  } else {
    keep(&mut checked.gitmodules, entry.id, admission)
  }
}

/// The whole tree's flags as `fsck_tree` reports them after its walk, in its order.
fn report_flags(flags: &Flags, report: &mut Report) {
  let raised = [
    (flags.null_id, FsckId::NullSha1),
    (flags.full_path, FsckId::FullPathname),
    (flags.empty_name, FsckId::EmptyName),
    (flags.dot, FsckId::HasDot),
    (flags.dotdot, FsckId::HasDotdot),
    (flags.dotgit, FsckId::HasDotgit),
    (flags.zero_padded, FsckId::ZeroPaddedFilemode),
    (flags.bad_mode, FsckId::BadFilemode),
    (flags.duplicate, FsckId::DuplicateEntries),
    (flags.unsorted, FsckId::TreeNotSorted),
    (flags.large_name, FsckId::LargePathname),
  ];
  for (_, id) in raised.iter().filter(|(raised, _)| *raised) {
    report.report(*id);
  }
}
