//! git's tree, commit and tag objects, parsed and written byte for byte, and git's fsck checks over each (A-590;
//! §4.17.2 "Pieces (git)", piece 4). A push checks every new object with these checks as `transfer.fsckObjects` does,
//! always (§4.17.2 "A push", step 4), and a tree git once wrote with a mode or an order fsck now only warns about is
//! still served byte for byte ("Trees as a volume"), so each object keeps its bytes as written.
//!
//! - [`tree`]: entries (mode, name, id), git's sort order, the modes git writes and the ones fsck flags.
//! - [`commit`] and [`tag`]: headers (each with its continuation lines, as `gpgsig` and `mergetag` carry them, and any
//!   extra header), and the message; a tag's signature is the block that ends its message.
//! - [`fsck`]: each of fsck.h's message ids at its default severity; a check's report lists what git reports, in git's
//!   order, and where git stops checking an object, it stops.
//!
//! **Sources** (git v2.50.1, read 2026-11-19). `fsck.h` (`FOREACH_FSCK_MSG_ID`, each id's default severity) and `fsck.c`
//! (`fsck_tree`, `verify_ordered`, `verify_headers`, `fsck_ident`, `fsck_commit`, `fsck_tag_standalone`, `report`)
//! [C]; `tree-walk.c` (`decode_tree_entry`) and `object.h` (`parse_mode`) for a tree's entries; `utf8.c`
//! (`is_hfs_dot_generic`) and `path.c` (`is_ntfs_dotgit`, `is_ntfs_dot_generic`) for the names a checkout must never
//! write; `refs.c` (`check_refname_format`) for a tag's name; `date.c` (`date_overflows`) for a date; and
//! Documentation/gitformat-signature.txt [B] for signatures. Where git's C reads past what it checked (it relies on
//! `verify_headers` having found a newline to stop at), this code reads only what is there.
//!
//! **Golden vectors.** `fixtures/objects/` holds objects stock git 2.50.1 (Apple Git-155) wrote in a SHA-1 and a
//! SHA-256 repository, the well-formed ones by git's own commands and the malformed ones as git's own
//! `t/t1450-fsck.sh` makes them, with what `git fsck` and `git hash-object` said of each. `fixtures/make-objects.sh`
//! made them on 2026-11-19; `fixtures/objects/SHA256SUMS` holds each file's SHA-256, and each object's id is checked
//! against its bytes in the tests.
//!
//! **Hostile input (§4.9).** Every byte is untrusted: every length is checked against what is left before it is read,
//! nothing recurses, a parse that cannot hold the bytes is a typed refusal naming where it stopped, and what a parse
//! builds beside the bytes it borrows is charged to the caller's [`crate::Admission`] first. An object id comes in as
//! bytes of the repository's hash length; hashing is the object codec's (piece 2), never done here.

pub mod commit;
mod dotgit;
pub mod fsck;
mod headers;
mod hex;
mod ident;
mod refname;
pub mod tag;
pub mod tree;

#[cfg(test)]
mod tests;

pub use fsck::{FsckId, Report, Severity, Strictness};
pub use headers::{Header, ObjectRefused, Refusal};

/// A repository's object format, which fixes the length of every object id in it.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ObjectFormat {
  /// SHA-1 (`extensions.objectFormat=sha1`, git's default).
  Sha1,
  /// SHA-256 (`extensions.objectFormat=sha256`).
  Sha256,
}

impl ObjectFormat {
  /// Format: the bytes of an object id (git's `the_hash_algo->rawsz`: 20 for SHA-1, 32 for SHA-256).
  pub const fn raw_len(self) -> usize {
    match self {
      Self::Sha1 => 20,
      Self::Sha256 => 32,
    }
  }

  /// Format: the hexadecimal digits of an object id written as text (`hexsz`: two a byte).
  pub const fn hex_len(self) -> usize {
    match self {
      Self::Sha1 => 40,
      Self::Sha256 => 64,
    }
  }
}

/// An object's type as git names it (`object.c`'s `type_name`), in a tag's `type` header or an object's own header.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ObjectType {
  /// `blob`.
  Blob,
  /// `tree`.
  Tree,
  /// `commit`.
  Commit,
  /// `tag`.
  Tag,
}

impl ObjectType {
  /// The type's name.
  pub const fn name(self) -> &'static [u8] {
    match self {
      Self::Blob => b"blob",
      Self::Tree => b"tree",
      Self::Commit => b"commit",
      Self::Tag => b"tag",
    }
  }

  /// The type `name` names exactly, as `type_from_string_gently` reads it; none for any other bytes.
  pub fn from_name(name: &[u8]) -> Option<Self> {
    [Self::Blob, Self::Tree, Self::Commit, Self::Tag]
      .into_iter()
      .find(|kind| kind.name() == name)
  }
}
