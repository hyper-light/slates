//! git's fsck message ids and severities (A-590; fsck.h's `FOREACH_FSCK_MSG_ID` and `enum fsck_msg_type`), and a
//! check's report: what git reports of one object, in git's order, each a typed refusal or a typed warning by its
//! severity.
//!
//! git's `report` (fsck.c) turns a fatal finding into an error and an info into a warning, prints nothing for an ignored
//! one, and under `--strict` turns a warning into an error. A commit's and a tag's check stops at its first error (each
//! `if (err) return err`); a tree's reports every flag it raised. [`Report`] keeps every finding, the ignored ones too, so
//! a policy that elevates one (as `fsck.<id>=error` does) has it to read.

/// A message's default severity (fsck.h `enum fsck_msg_type`).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Severity {
  /// Stops the check at once; reported as an error.
  Fatal,
  /// Refuses the object.
  Error,
  /// Reported, and the object is kept.
  Warn,
  /// "reported as warnings, but ignored by default" (fsck.h): reported as a warning.
  Info,
  /// "ignored (elevated when requested)" (fsck.h): not reported.
  Ignore,
}

/// Which of fsck's two strictnesses a check runs under (`fsck_options.strict`).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Strictness {
  /// `git fsck`'s and `transfer.fsckObjects`' default.
  Default,
  /// `--strict` (and `git hash-object`'s check): a warning refuses, and a tree's mode 100664 is a bad mode.
  Strict,
}

impl Severity {
  /// The severity a finding is reported at under `strictness` (fsck.c `fsck_msg_type` and `fsck_vreport`): fatal as an
  /// error, info as a warning, a warning as an error under `--strict`.
  pub const fn reported(self, strictness: Strictness) -> Severity {
    match (self, strictness) {
      (Severity::Fatal, _) | (Severity::Warn, Strictness::Strict) => Severity::Error,
      (Severity::Info, _) => Severity::Warn,
      (other, _) => other,
    }
  }
}

/// fsck.h's message ids (`FOREACH_FSCK_MSG_ID`), in its order, each with its default severity ([`FsckId::severity`])
/// and the name git prints ([`FsckId::name`]). The tree, commit and tag checks here report the ones `fsck_tree`,
/// `fsck_commit`, `fsck_tag_standalone` and `fsck_ident` report; the others are a ref's, a packed-refs file's and a
/// `.gitmodules` or `.gitattributes` blob's, kept so each of git's checks has its one typed name.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum FsckId {
  /// `NUL_IN_HEADER` (fatal), printed `nulInHeader`.
  NulInHeader,
  /// `UNTERMINATED_HEADER` (fatal), printed `unterminatedHeader`.
  UnterminatedHeader,
  /// `BAD_DATE` (error), printed `badDate`.
  BadDate,
  /// `BAD_DATE_OVERFLOW` (error), printed `badDateOverflow`.
  BadDateOverflow,
  /// `BAD_EMAIL` (error), printed `badEmail`.
  BadEmail,
  /// `BAD_NAME` (error), printed `badName`.
  BadName,
  /// `BAD_OBJECT_SHA1` (error), printed `badObjectSha1`.
  BadObjectSha1,
  /// `BAD_PACKED_REF_ENTRY` (error), printed `badPackedRefEntry`.
  BadPackedRefEntry,
  /// `BAD_PACKED_REF_HEADER` (error), printed `badPackedRefHeader`.
  BadPackedRefHeader,
  /// `BAD_PARENT_SHA1` (error), printed `badParentSha1`.
  BadParentSha1,
  /// `BAD_REF_CONTENT` (error), printed `badRefContent`.
  BadRefContent,
  /// `BAD_REF_FILETYPE` (error), printed `badRefFiletype`.
  BadRefFiletype,
  /// `BAD_REF_NAME` (error), printed `badRefName`.
  BadRefName,
  /// `BAD_REFERENT_NAME` (error), printed `badReferentName`.
  BadReferentName,
  /// `BAD_TIMEZONE` (error), printed `badTimezone`.
  BadTimezone,
  /// `BAD_TREE` (error), printed `badTree`.
  BadTree,
  /// `BAD_TREE_SHA1` (error), printed `badTreeSha1`.
  BadTreeSha1,
  /// `BAD_TYPE` (error), printed `badType`.
  BadType,
  /// `DUPLICATE_ENTRIES` (error), printed `duplicateEntries`.
  DuplicateEntries,
  /// `MISSING_AUTHOR` (error), printed `missingAuthor`.
  MissingAuthor,
  /// `MISSING_COMMITTER` (error), printed `missingCommitter`.
  MissingCommitter,
  /// `MISSING_EMAIL` (error), printed `missingEmail`.
  MissingEmail,
  /// `MISSING_NAME_BEFORE_EMAIL` (error), printed `missingNameBeforeEmail`.
  MissingNameBeforeEmail,
  /// `MISSING_OBJECT` (error), printed `missingObject`.
  MissingObject,
  /// `MISSING_SPACE_BEFORE_DATE` (error), printed `missingSpaceBeforeDate`.
  MissingSpaceBeforeDate,
  /// `MISSING_SPACE_BEFORE_EMAIL` (error), printed `missingSpaceBeforeEmail`.
  MissingSpaceBeforeEmail,
  /// `MISSING_TAG` (error), printed `missingTag`.
  MissingTag,
  /// `MISSING_TAG_ENTRY` (error), printed `missingTagEntry`.
  MissingTagEntry,
  /// `MISSING_TREE` (error), printed `missingTree`.
  MissingTree,
  /// `MISSING_TYPE` (error), printed `missingType`.
  MissingType,
  /// `MISSING_TYPE_ENTRY` (error), printed `missingTypeEntry`.
  MissingTypeEntry,
  /// `MULTIPLE_AUTHORS` (error), printed `multipleAuthors`.
  MultipleAuthors,
  /// `PACKED_REF_ENTRY_NOT_TERMINATED` (error), printed `packedRefEntryNotTerminated`.
  PackedRefEntryNotTerminated,
  /// `PACKED_REF_UNSORTED` (error), printed `packedRefUnsorted`.
  PackedRefUnsorted,
  /// `TREE_NOT_SORTED` (error), printed `treeNotSorted`.
  TreeNotSorted,
  /// `UNKNOWN_TYPE` (error), printed `unknownType`.
  UnknownType,
  /// `ZERO_PADDED_DATE` (error), printed `zeroPaddedDate`.
  ZeroPaddedDate,
  /// `GITMODULES_MISSING` (error), printed `gitmodulesMissing`.
  GitmodulesMissing,
  /// `GITMODULES_BLOB` (error), printed `gitmodulesBlob`.
  GitmodulesBlob,
  /// `GITMODULES_LARGE` (error), printed `gitmodulesLarge`.
  GitmodulesLarge,
  /// `GITMODULES_NAME` (error), printed `gitmodulesName`.
  GitmodulesName,
  /// `GITMODULES_SYMLINK` (error), printed `gitmodulesSymlink`.
  GitmodulesSymlink,
  /// `GITMODULES_URL` (error), printed `gitmodulesUrl`.
  GitmodulesUrl,
  /// `GITMODULES_PATH` (error), printed `gitmodulesPath`.
  GitmodulesPath,
  /// `GITMODULES_UPDATE` (error), printed `gitmodulesUpdate`.
  GitmodulesUpdate,
  /// `GITATTRIBUTES_MISSING` (error), printed `gitattributesMissing`.
  GitattributesMissing,
  /// `GITATTRIBUTES_LARGE` (error), printed `gitattributesLarge`.
  GitattributesLarge,
  /// `GITATTRIBUTES_LINE_LENGTH` (error), printed `gitattributesLineLength`.
  GitattributesLineLength,
  /// `GITATTRIBUTES_BLOB` (error), printed `gitattributesBlob`.
  GitattributesBlob,
  /// `EMPTY_NAME` (warn), printed `emptyName`.
  EmptyName,
  /// `FULL_PATHNAME` (warn), printed `fullPathname`.
  FullPathname,
  /// `HAS_DOT` (warn), printed `hasDot`.
  HasDot,
  /// `HAS_DOTDOT` (warn), printed `hasDotdot`.
  HasDotdot,
  /// `HAS_DOTGIT` (warn), printed `hasDotgit`.
  HasDotgit,
  /// `NULL_SHA1` (warn), printed `nullSha1`.
  NullSha1,
  /// `ZERO_PADDED_FILEMODE` (warn), printed `zeroPaddedFilemode`.
  ZeroPaddedFilemode,
  /// `NUL_IN_COMMIT` (warn), printed `nulInCommit`.
  NulInCommit,
  /// `LARGE_PATHNAME` (warn), printed `largePathname`.
  LargePathname,
  /// `BAD_FILEMODE` (info), printed `badFilemode`.
  BadFilemode,
  /// `EMPTY_PACKED_REFS_FILE` (info), printed `emptyPackedRefsFile`.
  EmptyPackedRefsFile,
  /// `GITMODULES_PARSE` (info), printed `gitmodulesParse`.
  GitmodulesParse,
  /// `GITIGNORE_SYMLINK` (info), printed `gitignoreSymlink`.
  GitignoreSymlink,
  /// `GITATTRIBUTES_SYMLINK` (info), printed `gitattributesSymlink`.
  GitattributesSymlink,
  /// `MAILMAP_SYMLINK` (info), printed `mailmapSymlink`.
  MailmapSymlink,
  /// `BAD_TAG_NAME` (info), printed `badTagName`.
  BadTagName,
  /// `MISSING_TAGGER_ENTRY` (info), printed `missingTaggerEntry`.
  MissingTaggerEntry,
  /// `SYMLINK_REF` (info), printed `symlinkRef`.
  SymlinkRef,
  /// `REF_MISSING_NEWLINE` (info), printed `refMissingNewline`.
  RefMissingNewline,
  /// `SYMREF_TARGET_IS_NOT_A_REF` (info), printed `symrefTargetIsNotARef`.
  SymrefTargetIsNotARef,
  /// `TRAILING_REF_CONTENT` (info), printed `trailingRefContent`.
  TrailingRefContent,
  /// `EXTRA_HEADER_ENTRY` (ignore), printed `extraHeaderEntry`.
  ExtraHeaderEntry,
}

impl FsckId {
  /// Every id, in fsck.h's order.
  pub const ALL: [FsckId; 71] = [
    FsckId::NulInHeader,
    FsckId::UnterminatedHeader,
    FsckId::BadDate,
    FsckId::BadDateOverflow,
    FsckId::BadEmail,
    FsckId::BadName,
    FsckId::BadObjectSha1,
    FsckId::BadPackedRefEntry,
    FsckId::BadPackedRefHeader,
    FsckId::BadParentSha1,
    FsckId::BadRefContent,
    FsckId::BadRefFiletype,
    FsckId::BadRefName,
    FsckId::BadReferentName,
    FsckId::BadTimezone,
    FsckId::BadTree,
    FsckId::BadTreeSha1,
    FsckId::BadType,
    FsckId::DuplicateEntries,
    FsckId::MissingAuthor,
    FsckId::MissingCommitter,
    FsckId::MissingEmail,
    FsckId::MissingNameBeforeEmail,
    FsckId::MissingObject,
    FsckId::MissingSpaceBeforeDate,
    FsckId::MissingSpaceBeforeEmail,
    FsckId::MissingTag,
    FsckId::MissingTagEntry,
    FsckId::MissingTree,
    FsckId::MissingType,
    FsckId::MissingTypeEntry,
    FsckId::MultipleAuthors,
    FsckId::PackedRefEntryNotTerminated,
    FsckId::PackedRefUnsorted,
    FsckId::TreeNotSorted,
    FsckId::UnknownType,
    FsckId::ZeroPaddedDate,
    FsckId::GitmodulesMissing,
    FsckId::GitmodulesBlob,
    FsckId::GitmodulesLarge,
    FsckId::GitmodulesName,
    FsckId::GitmodulesSymlink,
    FsckId::GitmodulesUrl,
    FsckId::GitmodulesPath,
    FsckId::GitmodulesUpdate,
    FsckId::GitattributesMissing,
    FsckId::GitattributesLarge,
    FsckId::GitattributesLineLength,
    FsckId::GitattributesBlob,
    FsckId::EmptyName,
    FsckId::FullPathname,
    FsckId::HasDot,
    FsckId::HasDotdot,
    FsckId::HasDotgit,
    FsckId::NullSha1,
    FsckId::ZeroPaddedFilemode,
    FsckId::NulInCommit,
    FsckId::LargePathname,
    FsckId::BadFilemode,
    FsckId::EmptyPackedRefsFile,
    FsckId::GitmodulesParse,
    FsckId::GitignoreSymlink,
    FsckId::GitattributesSymlink,
    FsckId::MailmapSymlink,
    FsckId::BadTagName,
    FsckId::MissingTaggerEntry,
    FsckId::SymlinkRef,
    FsckId::RefMissingNewline,
    FsckId::SymrefTargetIsNotARef,
    FsckId::TrailingRefContent,
    FsckId::ExtraHeaderEntry,
  ];

  /// The id's default severity (fsck.h), before any configuration changes it.
  pub const fn severity(self) -> Severity {
    match self {
      FsckId::NulInHeader => Severity::Fatal,
      FsckId::UnterminatedHeader => Severity::Fatal,
      FsckId::BadDate => Severity::Error,
      FsckId::BadDateOverflow => Severity::Error,
      FsckId::BadEmail => Severity::Error,
      FsckId::BadName => Severity::Error,
      FsckId::BadObjectSha1 => Severity::Error,
      FsckId::BadPackedRefEntry => Severity::Error,
      FsckId::BadPackedRefHeader => Severity::Error,
      FsckId::BadParentSha1 => Severity::Error,
      FsckId::BadRefContent => Severity::Error,
      FsckId::BadRefFiletype => Severity::Error,
      FsckId::BadRefName => Severity::Error,
      FsckId::BadReferentName => Severity::Error,
      FsckId::BadTimezone => Severity::Error,
      FsckId::BadTree => Severity::Error,
      FsckId::BadTreeSha1 => Severity::Error,
      FsckId::BadType => Severity::Error,
      FsckId::DuplicateEntries => Severity::Error,
      FsckId::MissingAuthor => Severity::Error,
      FsckId::MissingCommitter => Severity::Error,
      FsckId::MissingEmail => Severity::Error,
      FsckId::MissingNameBeforeEmail => Severity::Error,
      FsckId::MissingObject => Severity::Error,
      FsckId::MissingSpaceBeforeDate => Severity::Error,
      FsckId::MissingSpaceBeforeEmail => Severity::Error,
      FsckId::MissingTag => Severity::Error,
      FsckId::MissingTagEntry => Severity::Error,
      FsckId::MissingTree => Severity::Error,
      FsckId::MissingType => Severity::Error,
      FsckId::MissingTypeEntry => Severity::Error,
      FsckId::MultipleAuthors => Severity::Error,
      FsckId::PackedRefEntryNotTerminated => Severity::Error,
      FsckId::PackedRefUnsorted => Severity::Error,
      FsckId::TreeNotSorted => Severity::Error,
      FsckId::UnknownType => Severity::Error,
      FsckId::ZeroPaddedDate => Severity::Error,
      FsckId::GitmodulesMissing => Severity::Error,
      FsckId::GitmodulesBlob => Severity::Error,
      FsckId::GitmodulesLarge => Severity::Error,
      FsckId::GitmodulesName => Severity::Error,
      FsckId::GitmodulesSymlink => Severity::Error,
      FsckId::GitmodulesUrl => Severity::Error,
      FsckId::GitmodulesPath => Severity::Error,
      FsckId::GitmodulesUpdate => Severity::Error,
      FsckId::GitattributesMissing => Severity::Error,
      FsckId::GitattributesLarge => Severity::Error,
      FsckId::GitattributesLineLength => Severity::Error,
      FsckId::GitattributesBlob => Severity::Error,
      FsckId::EmptyName => Severity::Warn,
      FsckId::FullPathname => Severity::Warn,
      FsckId::HasDot => Severity::Warn,
      FsckId::HasDotdot => Severity::Warn,
      FsckId::HasDotgit => Severity::Warn,
      FsckId::NullSha1 => Severity::Warn,
      FsckId::ZeroPaddedFilemode => Severity::Warn,
      FsckId::NulInCommit => Severity::Warn,
      FsckId::LargePathname => Severity::Warn,
      FsckId::BadFilemode => Severity::Info,
      FsckId::EmptyPackedRefsFile => Severity::Info,
      FsckId::GitmodulesParse => Severity::Info,
      FsckId::GitignoreSymlink => Severity::Info,
      FsckId::GitattributesSymlink => Severity::Info,
      FsckId::MailmapSymlink => Severity::Info,
      FsckId::BadTagName => Severity::Info,
      FsckId::MissingTaggerEntry => Severity::Info,
      FsckId::SymlinkRef => Severity::Info,
      FsckId::RefMissingNewline => Severity::Info,
      FsckId::SymrefTargetIsNotARef => Severity::Info,
      FsckId::TrailingRefContent => Severity::Info,
      FsckId::ExtraHeaderEntry => Severity::Ignore,
    }
  }

  /// The id as git prints it (`prepare_msg_ids`: lower case, each word after the first capitalized, no `_`).
  pub const fn name(self) -> &'static str {
    match self {
      FsckId::NulInHeader => "nulInHeader",
      FsckId::UnterminatedHeader => "unterminatedHeader",
      FsckId::BadDate => "badDate",
      FsckId::BadDateOverflow => "badDateOverflow",
      FsckId::BadEmail => "badEmail",
      FsckId::BadName => "badName",
      FsckId::BadObjectSha1 => "badObjectSha1",
      FsckId::BadPackedRefEntry => "badPackedRefEntry",
      FsckId::BadPackedRefHeader => "badPackedRefHeader",
      FsckId::BadParentSha1 => "badParentSha1",
      FsckId::BadRefContent => "badRefContent",
      FsckId::BadRefFiletype => "badRefFiletype",
      FsckId::BadRefName => "badRefName",
      FsckId::BadReferentName => "badReferentName",
      FsckId::BadTimezone => "badTimezone",
      FsckId::BadTree => "badTree",
      FsckId::BadTreeSha1 => "badTreeSha1",
      FsckId::BadType => "badType",
      FsckId::DuplicateEntries => "duplicateEntries",
      FsckId::MissingAuthor => "missingAuthor",
      FsckId::MissingCommitter => "missingCommitter",
      FsckId::MissingEmail => "missingEmail",
      FsckId::MissingNameBeforeEmail => "missingNameBeforeEmail",
      FsckId::MissingObject => "missingObject",
      FsckId::MissingSpaceBeforeDate => "missingSpaceBeforeDate",
      FsckId::MissingSpaceBeforeEmail => "missingSpaceBeforeEmail",
      FsckId::MissingTag => "missingTag",
      FsckId::MissingTagEntry => "missingTagEntry",
      FsckId::MissingTree => "missingTree",
      FsckId::MissingType => "missingType",
      FsckId::MissingTypeEntry => "missingTypeEntry",
      FsckId::MultipleAuthors => "multipleAuthors",
      FsckId::PackedRefEntryNotTerminated => "packedRefEntryNotTerminated",
      FsckId::PackedRefUnsorted => "packedRefUnsorted",
      FsckId::TreeNotSorted => "treeNotSorted",
      FsckId::UnknownType => "unknownType",
      FsckId::ZeroPaddedDate => "zeroPaddedDate",
      FsckId::GitmodulesMissing => "gitmodulesMissing",
      FsckId::GitmodulesBlob => "gitmodulesBlob",
      FsckId::GitmodulesLarge => "gitmodulesLarge",
      FsckId::GitmodulesName => "gitmodulesName",
      FsckId::GitmodulesSymlink => "gitmodulesSymlink",
      FsckId::GitmodulesUrl => "gitmodulesUrl",
      FsckId::GitmodulesPath => "gitmodulesPath",
      FsckId::GitmodulesUpdate => "gitmodulesUpdate",
      FsckId::GitattributesMissing => "gitattributesMissing",
      FsckId::GitattributesLarge => "gitattributesLarge",
      FsckId::GitattributesLineLength => "gitattributesLineLength",
      FsckId::GitattributesBlob => "gitattributesBlob",
      FsckId::EmptyName => "emptyName",
      FsckId::FullPathname => "fullPathname",
      FsckId::HasDot => "hasDot",
      FsckId::HasDotdot => "hasDotdot",
      FsckId::HasDotgit => "hasDotgit",
      FsckId::NullSha1 => "nullSha1",
      FsckId::ZeroPaddedFilemode => "zeroPaddedFilemode",
      FsckId::NulInCommit => "nulInCommit",
      FsckId::LargePathname => "largePathname",
      FsckId::BadFilemode => "badFilemode",
      FsckId::EmptyPackedRefsFile => "emptyPackedRefsFile",
      FsckId::GitmodulesParse => "gitmodulesParse",
      FsckId::GitignoreSymlink => "gitignoreSymlink",
      FsckId::GitattributesSymlink => "gitattributesSymlink",
      FsckId::MailmapSymlink => "mailmapSymlink",
      FsckId::BadTagName => "badTagName",
      FsckId::MissingTaggerEntry => "missingTaggerEntry",
      FsckId::SymlinkRef => "symlinkRef",
      FsckId::RefMissingNewline => "refMissingNewline",
      FsckId::SymrefTargetIsNotARef => "symrefTargetIsNotARef",
      FsckId::TrailingRefContent => "trailingRefContent",
      FsckId::ExtraHeaderEntry => "extraHeaderEntry",
    }
  }
}

/// What a check found in one object: each finding in the order git reports it, under one strictness.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Report {
  /// The findings, ignored ones included, each once. Bounded by the ids there are.
  findings: Vec<FsckId>,
  /// The strictness the check ran under.
  strictness: Strictness,
}

impl Report {
  /// An empty report.
  pub(crate) fn new(strictness: Strictness) -> Self {
    Self {
      findings: Vec::new(),
      strictness,
    }
  }

  /// Records `id` at its first report (git prints a tree's symbolic-link findings once for each entry; one is enough to
  /// type it, and keeps the report bounded by the ids there are); true when it refuses the object, where a commit's
  /// or a tag's check stops.
  pub(crate) fn report(&mut self, id: FsckId) -> bool {
    if !self.findings.contains(&id) {
      self.findings.push(id);
    }
    id.severity().reported(self.strictness) == Severity::Error
  }

  /// Every finding, in git's order, ignored ones included.
  pub fn findings(&self) -> &[FsckId] {
    &self.findings
  }

  /// The findings git reports (every one but the ignored), in its order.
  pub fn reported(&self) -> impl Iterator<Item = FsckId> + '_ {
    let strictness = self.strictness;
    self
      .findings
      .iter()
      .copied()
      .filter(move |id| id.severity().reported(strictness) != Severity::Ignore)
  }

  /// The first finding that refuses the object, if any: the typed refusal.
  pub fn refusal(&self) -> Option<FsckId> {
    let strictness = self.strictness;
    self
      .findings
      .iter()
      .copied()
      .find(|id| id.severity().reported(strictness) == Severity::Error)
  }

  /// The findings reported as warnings: the object is kept, and these are said of it.
  pub fn warnings(&self) -> impl Iterator<Item = FsckId> + '_ {
    let strictness = self.strictness;
    self
      .findings
      .iter()
      .copied()
      .filter(move |id| id.severity().reported(strictness) == Severity::Warn)
  }
}
