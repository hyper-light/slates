//! A tag object (A-590): its headers (`object`, `type`, `tag`, `tagger`, and any other, each with its continuation
//! lines) and its message, whose last lines may be a signature block, parsed as written, written back byte for byte, and
//! checked as git's `fsck_tag_standalone` (fsck.c) checks them.

use super::fsck::{FsckId, Report, Strictness};
use super::headers::{self, Header, ObjectRefused};
use super::{ObjectFormat, ObjectType, hex, ident, refname};
use crate::Admission;

/// Format: the first lines of the signature blocks git recognizes at the end of a tag's message
/// (`gpg-interface.c`'s formats: OpenPGP, X.509 and SSH).
const SIGNATURE_STARTS: [&[u8]; 4] = [
  b"-----BEGIN PGP SIGNATURE-----",
  b"-----BEGIN PGP MESSAGE-----",
  b"-----BEGIN SIGNED MESSAGE-----",
  b"-----BEGIN SSH SIGNATURE-----",
];

/// A tag: its headers in the order written and its message.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Tag<'a> {
  /// The headers.
  headers: Vec<Header<'a>>,
  /// The message after the empty line; none when the headers end the object.
  message: Option<&'a [u8]>,
}

impl<'a> Tag<'a> {
  /// Parses `bytes`, a tag's content, charging its headers to `admission` before any is kept. Only a NUL in the headers
  /// or headers with no newline after the last are refused; the rest is [`fsck`]'s to judge.
  pub fn parse(bytes: &'a [u8], admission: &mut Admission) -> Result<Self, ObjectRefused> {
    headers::verify(bytes)?;
    let (head, message) = headers::split(bytes);
    Ok(Self {
      headers: headers::parse(head, admission)?,
      message,
    })
  }

  /// Every header in the order written.
  pub fn headers(&self) -> &[Header<'a>] {
    &self.headers
  }

  /// The value of the first header named `name`.
  fn first(&self, name: &[u8]) -> Option<&'a [u8]> {
    self
      .headers
      .iter()
      .find(|header| header.name == name)
      .and_then(|header| header.value)
  }

  /// The tagged object's id as written.
  pub fn object(&self) -> Option<&'a [u8]> {
    self.first(b"object")
  }

  /// The tagged object's type, when the `type` header names one.
  pub fn kind(&self) -> Option<ObjectType> {
    self.first(b"type").and_then(ObjectType::from_name)
  }

  /// The tag's name.
  pub fn name(&self) -> Option<&'a [u8]> {
    self.first(b"tag")
  }

  /// The `tagger` line's value (early tags have none).
  pub fn tagger(&self) -> Option<&'a [u8]> {
    self.first(b"tagger")
  }

  /// The message, the signature block included.
  pub fn message(&self) -> Option<&'a [u8]> {
    self.message
  }

  /// The message split where its signature block begins (git's `parse_signed_buffer`: the last line that starts a
  /// block it recognizes): the signed text and the block. None when the message ends with no such block.
  pub fn signature(&self) -> Option<(&'a [u8], &'a [u8])> {
    let message = self.message?;
    let mut start = None;
    let mut at = 0_usize;
    while at < message.len() {
      let rest = message.get(at..).unwrap_or_default();
      if SIGNATURE_STARTS.iter().any(|begin| rest.starts_with(begin)) {
        start = Some(at);
      }
      at = rest
        .iter()
        .position(|byte| *byte == b'\n')
        .map_or(message.len(), |end| at.saturating_add(end).saturating_add(1));
    }
    start.map(|at| message.split_at(at))
  }

  /// Writes the tag as it was read.
  pub fn write(&self, out: &mut impl crate::out::Out) {
    headers::write(&self.headers, self.message, out);
  }
}

/// Checks `bytes`, a tag's content in a repository of `format`, as git's `fsck_tag_standalone` does, under
/// `strictness`: the headers whole, then `object`, `type`, `tag` (its name as `refs/tags/<name>`), `tagger`, and no
/// header after it. It stops at a refusal where git's does: not at a bad tagger, whose walk goes on to the next check.
pub fn fsck(bytes: &[u8], format: ObjectFormat, strictness: Strictness) -> Report {
  let mut report = Report::new(strictness);
  if let Err(refused) = headers::verify(bytes) {
    if let Some(id) = refused.refusal.fsck_id() {
      report.report(id);
    }
    return report;
  }
  if let Err(id) = check(bytes, format, &mut report) {
    report.report(id);
  }
  report
}

/// The line that begins `rest`, without its newline, and what follows it; none when no newline ends it.
fn line(rest: &[u8]) -> Option<(&[u8], &[u8])> {
  let end = rest.iter().position(|byte| *byte == b'\n')?;
  Some((rest.get(..end)?, rest.get(end.saturating_add(1)..)?))
}

/// `fsck_tag_standalone`'s walk: the refusal that stops it, or Ok at its end, the findings it went on past reported.
fn check(bytes: &[u8], format: ObjectFormat, report: &mut Report) -> Result<(), FsckId> {
  let after = bytes.strip_prefix(b"object ").ok_or(FsckId::MissingObject)?;
  let object = hex::id_then(after, format, b'\n').ok_or(FsckId::BadObjectSha1)?;
  let rest = after.get(object.len().saturating_add(1)..).unwrap_or_default();
  let after = rest.strip_prefix(b"type ").ok_or(FsckId::MissingTypeEntry)?;
  let (kind, rest) = line(after).ok_or(FsckId::MissingType)?;
  ObjectType::from_name(kind).ok_or(FsckId::BadType)?;
  let after = rest.strip_prefix(b"tag ").ok_or(FsckId::MissingTagEntry)?;
  let (name, mut rest) = line(after).ok_or(FsckId::MissingTag)?;
  if !refname::tag_name_ok(name) && report.report(FsckId::BadTagName) {
    return Ok(());
  }
  match rest.strip_prefix(b"tagger ") {
    None => {
      if report.report(FsckId::MissingTaggerEntry) {
        return Ok(());
      }
    }
    Some(after) => {
      let (advance, finding) = ident::check(after);
      rest = after.get(advance..).unwrap_or_default();
      // git keeps the identity's finding and goes on to the next check without stopping.
      if let Some(id) = finding {
        report.report(id);
      }
    }
  }
  if !rest.is_empty() && !rest.starts_with(b"\n") && report.report(FsckId::ExtraHeaderEntry) {
    return Ok(());
  }
  Ok(())
}
