//! An object id written as text (A-590): git's `parse_oid_hex`, the repository's `hexsz` hexadecimal digits of either
//! case (`hexval`).

use super::ObjectFormat;

/// The value of hexadecimal digit `digit`, either case (git's `hexval`); none for any other byte.
pub(crate) fn digit(digit: u8) -> Option<u8> {
  match digit {
    b'0'..=b'9' => Some(digit.wrapping_sub(b'0')),
    b'a'..=b'f' => Some(digit.wrapping_sub(b'a').wrapping_add(10)),
    b'A'..=b'F' => Some(digit.wrapping_sub(b'A').wrapping_add(10)),
    _ => None,
  }
}

/// Whether `text` begins with an object id of `format` written in hexadecimal and goes on with `then` (git's
/// `parse_oid_hex(buffer, &oid, &p) || *p != then`, inverted): the id's digits when it does.
pub(crate) fn id_then(text: &[u8], format: ObjectFormat, then: u8) -> Option<&[u8]> {
  let digits = text.get(..format.hex_len())?;
  (digits.iter().all(|byte| digit(*byte).is_some()) && text.get(format.hex_len()) == Some(&then))
    .then_some(digits)
}

/// Writes the raw id `hex` names into `raw`, which holds the format's `raw_len` bytes; false when either length is not
/// the format's or a byte is no hexadecimal digit.
pub fn decode(hex: &[u8], raw: &mut [u8]) -> bool {
  if hex.len() != raw.len().saturating_mul(2) {
    return false;
  }
  for (pair, out) in hex.chunks_exact(2).zip(raw.iter_mut()) {
    let (Some(high), Some(low)) = (
      pair.first().copied().and_then(digit),
      pair.get(1).copied().and_then(digit),
    ) else {
      return false;
    };
    *out = high.wrapping_shl(4) | low;
  }
  true
}
