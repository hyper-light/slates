//! An `author`, `committer` or `tagger` line, checked as git's `fsck_ident` (fsck.c) checks it: a name, a space, an
//! email in angle brackets, a space, a date of decimal digits git can hold, a space and a time zone of a sign and four
//! digits, then the newline.

use super::FsckId;

/// Format: the bytes `strcspn(p, "<>\n")` stops at, with the NUL a C string ends at.
const IDENT_STOPS: &[u8] = b"<>\n\0";

/// Checks the identity line that begins `rest` (the bytes after `author `, `committer ` or `tagger `, to the object's
/// end): how far the line runs, its newline included (git moves past it before checking), and the finding git reports
/// of it, if any.
pub(crate) fn check(rest: &[u8]) -> (usize, Option<FsckId>) {
  let advance = rest
    .iter()
    .position(|byte| *byte == b'\n')
    .map_or(rest.len(), |at| at.saturating_add(1));
  (advance, finding(rest).err())
}

/// The byte at `at`, or the NUL a C string reads past its end.
fn at(rest: &[u8], at: usize) -> u8 {
  rest.get(at).copied().unwrap_or(b'\0')
}

/// The bytes before the first of [`IDENT_STOPS`] from `from`.
fn until_stop(rest: &[u8], from: usize) -> usize {
  rest
    .get(from..)
    .unwrap_or_default()
    .iter()
    .position(|byte| IDENT_STOPS.contains(byte))
    .unwrap_or_else(|| rest.len().saturating_sub(from))
}

/// `fsck_ident`'s checks in its order, each a finding.
fn finding(rest: &[u8]) -> Result<(), FsckId> {
  if at(rest, 0) == b'<' {
    return Err(FsckId::MissingNameBeforeEmail);
  }
  let mut p = until_stop(rest, 0);
  if at(rest, p) == b'>' {
    return Err(FsckId::BadName);
  }
  if at(rest, p) != b'<' {
    return Err(FsckId::MissingEmail);
  }
  // `p` is past the first byte here: a `<` there was refused above.
  if at(rest, p.saturating_sub(1)) != b' ' {
    return Err(FsckId::MissingSpaceBeforeEmail);
  }
  p = p.saturating_add(1);
  p = p.saturating_add(until_stop(rest, p));
  if at(rest, p) != b'>' {
    return Err(FsckId::BadEmail);
  }
  p = p.saturating_add(1);
  if at(rest, p) != b' ' {
    return Err(FsckId::MissingSpaceBeforeDate);
  }
  p = p.saturating_add(1);
  while matches!(at(rest, p), b' ' | b'\t') {
    p = p.saturating_add(1);
  }
  if !at(rest, p).is_ascii_digit() {
    return Err(FsckId::BadDate);
  }
  if at(rest, p) == b'0' && at(rest, p.saturating_add(1)) != b' ' {
    return Err(FsckId::ZeroPaddedDate);
  }
  let (date, end) = timestamp(rest, p);
  if overflows(date) {
    return Err(FsckId::BadDateOverflow);
  }
  if end == p || at(rest, end) != b' ' {
    return Err(FsckId::BadDate);
  }
  p = end.saturating_add(1);
  let zone_digits = (1..=4).all(|offset| at(rest, p.saturating_add(offset)).is_ascii_digit());
  if !matches!(at(rest, p), b'+' | b'-') || !zone_digits || at(rest, p.saturating_add(5)) != b'\n' {
    return Err(FsckId::BadTimezone);
  }
  Ok(())
}

/// git's `parse_timestamp` (`strtoumax` in base 10) from `from`: the value, `u64::MAX` past it as `strtoumax` answers,
/// and where the digits end.
fn timestamp(rest: &[u8], from: usize) -> (u64, usize) {
  let digits = rest
    .get(from..)
    .unwrap_or_default()
    .iter()
    .take_while(|byte| byte.is_ascii_digit())
    .count();
  let value = rest
    .get(from..from.saturating_add(digits))
    .unwrap_or_default()
    .iter()
    .try_fold(0_u64, |value, digit| {
      value
        .checked_mul(10)
        .and_then(|value| value.checked_add(u64::from(digit.wrapping_sub(b'0'))))
    })
    .unwrap_or(u64::MAX);
  (value, from.saturating_add(digits))
}

/// git's `date_overflows` (date.c): a timestamp at or past `timestamp_t`'s maximum, or one the signed `time_t` it is
/// handed on to cannot hold. With a 64-bit `time_t` that is any value past `i64::MAX`.
fn overflows(date: u64) -> bool {
  i64::try_from(date).is_err()
}
