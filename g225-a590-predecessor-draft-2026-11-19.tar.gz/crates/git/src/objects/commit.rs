//! A commit object (A-590): its headers (`tree`, each `parent`, `author`, `committer`, then `encoding`, `gpgsig`,
//! `gpgsig-sha256`, `mergetag` and any extra header, each with its continuation lines) and its message, parsed as
//! written, written back byte for byte, and checked as git's `fsck_commit` (fsck.c) checks them.

use super::fsck::{FsckId, Report, Strictness};
use super::headers::{self, Header, ObjectRefused};
use super::{ObjectFormat, hex, ident};
use crate::Admission;

/// A commit: its headers in the order written and its message.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Commit<'a> {
  /// The headers.
  headers: Vec<Header<'a>>,
  /// The message after the empty line; none when the headers end the object.
  message: Option<&'a [u8]>,
}

impl<'a> Commit<'a> {
  /// Parses `bytes`, a commit's content, charging its headers to `admission` before any is kept. Only what git's own
  /// check refuses outright is refused here (a NUL in the headers, or headers with no newline after the last); the
  /// rest is [`fsck`]'s to judge, so a commit git once wrote is still read and written back.
  pub fn parse(bytes: &'a [u8], admission: &mut Admission) -> Result<Self, ObjectRefused> {
    headers::verify(bytes)?;
    let (head, message) = headers::split(bytes);
    Ok(Self {
      headers: headers::parse(head, admission)?,
      message,
    })
  }

  /// Every header in the order written.
  pub fn headers(&self) -> &[Header<'a>] {
    &self.headers
  }

  /// The message, after the empty line that ends the headers.
  pub fn message(&self) -> Option<&'a [u8]> {
    self.message
  }

  /// The values of every header named `name`, in order.
  fn named(&self, name: &'static [u8]) -> impl Iterator<Item = &'a [u8]> + '_ {
    self
      .headers
      .iter()
      .filter(move |header| header.name == name)
      .filter_map(|header| header.value)
  }

  /// The tree's id as written (its hexadecimal digits), when the first header is `tree`.
  pub fn tree(&self) -> Option<&'a [u8]> {
    self
      .headers
      .first()
      .filter(|header| header.name == b"tree")
      .and_then(|header| header.value)
  }

  /// Each parent's id as written, the `parent` headers that follow `tree`.
  pub fn parents(&self) -> impl Iterator<Item = &'a [u8]> + '_ {
    self
      .headers
      .iter()
      .skip(1)
      .take_while(|header| header.name == b"parent")
      .filter_map(|header| header.value)
  }

  /// The `author` line's value.
  pub fn author(&self) -> Option<&'a [u8]> {
    self.named(b"author").next()
  }

  /// The `committer` line's value.
  pub fn committer(&self) -> Option<&'a [u8]> {
    self.named(b"committer").next()
  }

  /// The `encoding` header's value: the message's encoding, when not UTF-8.
  pub fn encoding(&self) -> Option<&'a [u8]> {
    self.named(b"encoding").next()
  }

  /// The signature headers (`gpgsig`, and `gpgsig-sha256` for the other object format), each with its lines.
  pub fn signatures(&self) -> impl Iterator<Item = &Header<'a>> + '_ {
    self
      .headers
      .iter()
      .filter(|header| header.name == b"gpgsig" || header.name == b"gpgsig-sha256")
  }

  /// The `mergetag` headers: each a whole tag object, its lines continuation lines.
  pub fn mergetags(&self) -> impl Iterator<Item = &Header<'a>> + '_ {
    self.headers.iter().filter(|header| header.name == b"mergetag")
  }

  /// The headers git gives no meaning of its own (gitformat-signature, "extra headers"), kept as written.
  pub fn extra_headers(&self) -> impl Iterator<Item = &Header<'a>> + '_ {
    const KNOWN: [&[u8]; 8] = [
      b"tree",
      b"parent",
      b"author",
      b"committer",
      b"encoding",
      b"gpgsig",
      b"gpgsig-sha256",
      b"mergetag",
    ];
    self
      .headers
      .iter()
      .filter(|header| !KNOWN.contains(&header.name))
  }

  /// Writes the commit as it was read.
  pub fn write(&self, out: &mut impl crate::out::Out) {
    headers::write(&self.headers, self.message, out);
  }
}

/// Checks `bytes`, a commit's content in a repository of `format`, as git's `fsck_commit` does, under `strictness`:
/// the headers whole, then `tree`, each `parent`, one `author`, `committer`, each identity checked, and a NUL anywhere.
/// The check stops at its first refusal, as git's does.
pub fn fsck(bytes: &[u8], format: ObjectFormat, strictness: Strictness) -> Report {
  let mut report = Report::new(strictness);
  if let Err(refused) = headers::verify(bytes) {
    if let Some(id) = refused.refusal.fsck_id() {
      report.report(id);
    }
    return report;
  }
  if let Err(id) = check(bytes, format) {
    report.report(id);
    return report;
  }
  if bytes.contains(&b'\0') {
    report.report(FsckId::NulInCommit);
  }
  report
}

/// `fsck_commit`'s header walk: the first refusal, or Ok once `committer` checks.
fn check(bytes: &[u8], format: ObjectFormat) -> Result<(), FsckId> {
  let mut rest = bytes.strip_prefix(b"tree ").ok_or(FsckId::MissingTree)?;
  let tree = hex::id_then(rest, format, b'\n').ok_or(FsckId::BadTreeSha1)?;
  rest = rest.get(tree.len().saturating_add(1)..).unwrap_or_default();
  while let Some(after) = rest.strip_prefix(b"parent ") {
    let parent = hex::id_then(after, format, b'\n').ok_or(FsckId::BadParentSha1)?;
    rest = after.get(parent.len().saturating_add(1)..).unwrap_or_default();
  }
  let mut authors = 0_usize;
  while let Some(after) = rest.strip_prefix(b"author ") {
    authors = authors.saturating_add(1);
    let (advance, finding) = ident::check(after);
    if let Some(id) = finding {
      return Err(id);
    }
    rest = after.get(advance..).unwrap_or_default();
  }
  match authors {
    0 => return Err(FsckId::MissingAuthor),
    1 => {}
    _ => return Err(FsckId::MultipleAuthors),
  }
  let after = rest.strip_prefix(b"committer ").ok_or(FsckId::MissingCommitter)?;
  match ident::check(after) {
    (_, Some(id)) => Err(id),
    (_, None) => Ok(()),
  }
}
