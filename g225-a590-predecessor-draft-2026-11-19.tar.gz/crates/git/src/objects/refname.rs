//! A tag's name, checked as git checks `refs/tags/<name>` (`check_refname_format` with no flags, refs.c): what
//! `git check-ref-format` documents, by git's own table of each byte's disposition.

/// What `refname_disposition` (refs.c) says of a byte inside a ref name's component.
#[derive(Clone, Copy, PartialEq, Eq)]
enum Disposition {
  /// Allowed.
  Plain,
  /// Ends the component: a NUL or a `/`.
  End,
  /// `.`: refused after another `.`.
  Dot,
  /// `{`: refused after `@`.
  Brace,
  /// Refused anywhere: a control character, space, `:`, `?`, `[`, `\`, `^`, `~` or DEL.
  Forbidden,
  /// `*`: refused, since this check is not a refspec pattern's.
  Star,
}

/// refs.c's `refname_disposition` table: bytes from 0x80 up are allowed.
fn disposition(byte: u8) -> Disposition {
  match byte {
    b'\0' | b'/' => Disposition::End,
    0x01..=0x20 | b':' | b'?' | b'[' | b'\\' | b'^' | b'~' | 0x7f => Disposition::Forbidden,
    b'.' => Disposition::Dot,
    b'{' => Disposition::Brace,
    b'*' => Disposition::Star,
    _ => Disposition::Plain,
  }
}

/// Format: the suffix a ref name's component may not end with (refs.c `LOCK_SUFFIX`).
const LOCK_SUFFIX: &[u8] = b".lock";

/// Whether one component (the bytes up to a `/` or the end) is allowed (`check_refname_component`).
fn component_ok(component: &[u8]) -> bool {
  let mut last = b'\0';
  for byte in component {
    match disposition(*byte) {
      Disposition::Forbidden | Disposition::Star | Disposition::End => return false,
      Disposition::Dot if last == b'.' => return false,
      Disposition::Brace if last == b'@' => return false,
      _ => {}
    }
    last = *byte;
  }
  !component.is_empty() && component.first() != Some(&b'.') && !component.ends_with(LOCK_SUFFIX)
}

/// Whether `refs/tags/<name>` is a ref name git accepts: `refs` and `tags` are, so each component of `name` must be, and
/// the last may not end with `.` (`check_or_sanitize_refname`); there are always the two components git asks for.
pub(crate) fn tag_name_ok(name: &[u8]) -> bool {
  name.split(|byte| *byte == b'/').all(component_ok) && name.last() != Some(&b'.')
}
