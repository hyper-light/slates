//! What a commit and a tag share (A-590): their header lines, each with the continuation lines that follow it, then an
//! empty line and the message; and the typed refusals of every parse here.
//!
//! git checks a commit's or a tag's headers before reading them (`verify_headers`, fsck.c): a NUL before the empty line
//! is `nulInHeader` and headers with no newline after the last are `unterminatedHeader`, both fatal. Past that check
//! every header line ends in a newline, which is what lets git's own scans stop there. A header whose name is not one
//! git knows is kept as written ("extra header", gitformat-signature), so a write gives back the bytes it read.

use super::FsckId;
use crate::{Admission, PastAdmission};

/// One header of a commit or a tag, as written: its name (the bytes before the first space of its first line) and its
/// value (the bytes after that space up to the newline that ends its last continuation line, the continuation lines'
/// newlines and leading spaces kept). A line with no space has no value.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Header<'a> {
  /// The name.
  pub name: &'a [u8],
  /// The value, continuation lines included as written.
  pub value: Option<&'a [u8]>,
}

impl<'a> Header<'a> {
  /// The value's lines with each continuation line's leading space taken off, as git reads a multi-line header
  /// (`read_commit_extra_header_lines`): the first line, then each continuation line.
  pub fn lines(&self) -> impl Iterator<Item = &'a [u8]> + 'a {
    let value = self.value.unwrap_or_default();
    value
      .split(|byte| *byte == b'\n')
      .enumerate()
      .map(|(index, line)| if index == 0 { line } else { line.strip_prefix(b" ").unwrap_or(line) })
  }

  /// Writes the header back as it was read: name, a space and the value where there is one, and the newline.
  pub fn write(&self, out: &mut impl crate::out::Out) {
    out.put(self.name);
    if let Some(value) = self.value {
      out.put(b" ");
      out.put(value);
    }
    out.put(b"\n");
  }
}

/// Why a parse could not hold an object's bytes, typed by what git says of the same bytes.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Refusal {
  /// A NUL before the headers' end (`nulInHeader`, fatal in git).
  NulInHeader,
  /// The headers end with no newline (`unterminatedHeader`, fatal in git).
  UnterminatedHeader,
  /// A tree's entries do not end in a NUL and an object id ("too-short tree object", `badTree`).
  TooShortTree,
  /// A tree entry's mode is not octal digits ending in a space ("malformed mode in tree entry", `badTree`).
  MalformedMode,
  /// A tree entry with no name ("empty filename in tree entry", `badTree`).
  EmptyName,
  /// A tree entry's object id runs past the tree's end ("too-short tree file", `badTree`).
  TruncatedEntry,
  /// What the parse would build is past the caller's admission.
  PastAdmission(PastAdmission),
}

impl Refusal {
  /// The fsck message git reports for the same bytes; none for a refusal of the caller's admission.
  pub fn fsck_id(self) -> Option<FsckId> {
    match self {
      Refusal::NulInHeader => Some(FsckId::NulInHeader),
      Refusal::UnterminatedHeader => Some(FsckId::UnterminatedHeader),
      Refusal::TooShortTree | Refusal::MalformedMode | Refusal::EmptyName | Refusal::TruncatedEntry => {
        Some(FsckId::BadTree)
      }
      Refusal::PastAdmission(_) => None,
    }
  }
}

/// A parse refused, at the offset into the object where it stopped.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ObjectRefused {
  /// The offset of the byte the parse stopped at.
  pub at: usize,
  /// Why.
  pub refusal: Refusal,
}

/// git's `verify_headers`: the offset of a NUL before the first empty line, or the headers ending with no newline; Ok
/// when the headers are whole.
pub(crate) fn verify(bytes: &[u8]) -> Result<(), ObjectRefused> {
  let mut previous = None;
  for (at, byte) in bytes.iter().enumerate() {
    match byte {
      b'\0' => {
        return Err(ObjectRefused {
          at,
          refusal: Refusal::NulInHeader,
        });
      }
      b'\n' if previous == Some(b'\n') => return Ok(()),
      _ => {}
    }
    previous = Some(*byte);
  }
  if bytes.last() == Some(&b'\n') {
    return Ok(());
  }
  Err(ObjectRefused {
    at: bytes.len(),
    refusal: Refusal::UnterminatedHeader,
  })
}

/// The headers' bytes (each line with its newline) and the message after the empty line, once [`verify`] passed: the
/// message is none when no empty line ends the headers.
pub(crate) fn split(bytes: &[u8]) -> (&[u8], Option<&[u8]>) {
  let blank = bytes.windows(2).position(|pair| pair == b"\n\n");
  match blank {
    Some(at) => {
      let (headers, rest) = bytes.split_at(at.saturating_add(1));
      (headers, Some(rest.get(1..).unwrap_or_default()))
    }
    None => (bytes, None),
  }
}

/// The headers in `headers` (whole lines, each ending in a newline), each with its continuation lines, charged to
/// `admission` before any is kept.
pub(crate) fn parse<'a>(
  headers: &'a [u8],
  admission: &mut Admission,
) -> Result<Vec<Header<'a>>, ObjectRefused> {
  let count = lines(headers).count();
  admission
    .charge_items::<Header<'a>>(count)
    .map_err(|past| ObjectRefused {
      at: 0,
      refusal: Refusal::PastAdmission(past),
    })?;
  let mut kept = Vec::with_capacity(count);
  kept.extend(lines(headers));
  Ok(kept)
}

/// Each header of `headers` in order: a line that does not begin with a space, and every continuation line after it.
fn lines(headers: &[u8]) -> impl Iterator<Item = Header<'_>> {
  let mut rest = headers;
  core::iter::from_fn(move || {
    if rest.is_empty() {
      return None;
    }
    // The header runs to the newline before the next line that does not begin with a space, or to the end.
    let mut end = rest.iter().position(|byte| *byte == b'\n').unwrap_or(rest.len());
    while rest.get(end.saturating_add(1)) == Some(&b' ') {
      let from = end.saturating_add(1);
      end = rest
        .get(from..)
        .and_then(|tail| tail.iter().position(|byte| *byte == b'\n'))
        .map_or(rest.len(), |at| from.saturating_add(at));
    }
    let header = rest.get(..end).unwrap_or_default();
    rest = rest.get(end.saturating_add(1)..).unwrap_or_default();
    Some(match header.iter().position(|byte| *byte == b' ') {
      Some(space) => Header {
        name: header.get(..space).unwrap_or_default(),
        value: header.get(space.saturating_add(1)..),
      },
      None => Header {
        name: header,
        value: None,
      },
    })
  })
}

/// Writes `headers` and the message as they were read.
pub(crate) fn write(headers: &[Header<'_>], message: Option<&[u8]>, out: &mut impl crate::out::Out) {
  for header in headers {
    header.write(out);
  }
  if let Some(message) = message {
    out.put(b"\n");
    out.put(message);
  }
}
