//! The names a checkout must never write, as git's fsck finds them in a tree (A-590): `.git` and the special dotfiles
//! (`.gitmodules`, `.gitattributes`, `.gitignore`, `.mailmap`) under the spellings HFS+ (utf8.c `is_hfs_dot_generic`:
//! case folded, the code points HFS+ ignores skipped) and NTFS (path.c `is_ntfs_dotgit`, `is_ntfs_dot_generic`: case
//! folded, trailing spaces and dots, an alternate stream after `:`, and the 8.3 short names) resolve to the same file.
//! git's C reads each name as a NUL-terminated string; this reads a byte past the name as that NUL.

/// The byte at `at` in `name`, or the NUL a C string ends with.
fn at(name: &[u8], at: usize) -> u8 {
  name.get(at).copied().unwrap_or(b'\0')
}

/// Format: the code points HFS+ ignores in a name, which `next_hfs_char` (utf8.c) skips: the zero-width and
/// directional formatting characters and the zero-width no-break space.
const HFS_IGNORED: [u32; 16] = [
  0x200c, 0x200d, 0x200e, 0x200f, 0x202a, 0x202b, 0x202c, 0x202d, 0x202e, 0x206a, 0x206b, 0x206c, 0x206d, 0x206e,
  0x206f, 0xfeff,
];

/// One UTF-8 character of `name` at `from` as git's `pick_one_utf8_char` decodes it (overlong forms, surrogates,
/// U+FFFE, U+FFFF and past U+10FFFF refused): the code point and where the next begins, or none for malformed UTF-8.
fn utf8_at(name: &[u8], from: usize) -> Option<(u32, usize)> {
  let byte = |offset: usize| at(name, from.saturating_add(offset));
  let (s0, s1, s2, s3) = (byte(0), byte(1), byte(2), byte(3));
  let tail = |b: u8| u32::from(b & 0x3f);
  let continuation = |b: u8| b & 0xc0 == 0x80;
  if s0 < 0x80 {
    Some((u32::from(s0), from.saturating_add(1)))
  } else if s0 & 0xe0 == 0xc0 {
    (continuation(s1) && s0 & 0xfe != 0xc0)
      .then(|| ((u32::from(s0 & 0x1f) << 6) | tail(s1), from.saturating_add(2)))
  } else if s0 & 0xf0 == 0xe0 {
    let overlong = s0 == 0xe0 && s1 & 0xe0 == 0x80;
    let surrogate = s0 == 0xed && s1 & 0xe0 == 0xa0;
    let nonchar = s0 == 0xef && s1 == 0xbf && s2 & 0xfe == 0xbe;
    (continuation(s1) && continuation(s2) && !overlong && !surrogate && !nonchar).then(|| {
      (
        (u32::from(s0 & 0x0f) << 12) | (tail(s1) << 6) | tail(s2),
        from.saturating_add(3),
      )
    })
  } else if s0 & 0xf8 == 0xf0 {
    let overlong = s0 == 0xf0 && s1 & 0xf0 == 0x80;
    let too_big = (s0 == 0xf4 && s1 > 0x8f) || s0 > 0xf4;
    (continuation(s1) && continuation(s2) && continuation(s3) && !overlong && !too_big).then(|| {
      (
        (u32::from(s0 & 0x07) << 18) | (tail(s1) << 12) | (tail(s2) << 6) | tail(s3),
        from.saturating_add(4),
      )
    })
  } else {
    None
  }
}

/// `next_hfs_char`: the next code point HFS+ does not ignore, from `from`, and where the one after begins; 0 at the
/// name's end, and 0 for good once the UTF-8 is malformed (`from` none).
fn next_hfs(name: &[u8], from: Option<usize>) -> (u32, Option<usize>) {
  let mut from = from;
  loop {
    let Some(here) = from else {
      return (0, None);
    };
    match utf8_at(name, here) {
      None => return (0, None),
      Some((code, next)) if HFS_IGNORED.contains(&code) => from = Some(next),
      Some((code, next)) => return (code, Some(next)),
    }
  }
}

/// `is_hfs_dot_generic`: whether `name` is `.` and `needle` (lower case ASCII) as HFS+ reads it, ending there or at a
/// `/` (`is_dir_sep` on the systems git's servers run on).
fn is_hfs_dot(name: &[u8], needle: &[u8]) -> bool {
  let (first, mut from) = next_hfs(name, Some(0));
  if first != u32::from(b'.') {
    return false;
  }
  for want in needle {
    let (code, next) = next_hfs(name, from);
    from = next;
    let Ok(code) = u8::try_from(code) else {
      return false;
    };
    if code > 127 || code.to_ascii_lowercase() != *want {
      return false;
    }
  }
  let (code, _) = next_hfs(name, from);
  code == 0 || code == u32::from(b'/')
}

/// `is_ntfs_dotgit`: `.git` or `git~1`, either case, then only spaces and dots up to the end, a separator (either
/// slash) or a `:`.
fn is_ntfs_git(name: &[u8]) -> bool {
  let ci = |offset: usize, want: u8| at(name, offset).to_ascii_lowercase() == want;
  let mut from = match at(name, 0) {
    b'.' if ci(1, b'g') && ci(2, b'i') && ci(3, b't') => 4_usize,
    b'g' | b'G' if ci(1, b'i') && ci(2, b't') && at(name, 3) == b'~' && at(name, 4) == b'1' => 5_usize,
    _ => return false,
  };
  loop {
    let byte = at(name, from);
    from = from.saturating_add(1);
    if matches!(byte, b'\0' | b'/' | b'\\' | b':') {
      return true;
    }
    if byte != b'.' && byte != b' ' {
      return false;
    }
  }
}

/// Whether `name` from `from` holds nothing but spaces and dots up to its end or a `:` (`only_spaces_and_periods`).
fn only_spaces_and_dots(name: &[u8], from: usize) -> bool {
  let mut from = from;
  loop {
    let byte = at(name, from);
    from = from.saturating_add(1);
    if byte == b'\0' || byte == b':' {
      return true;
    }
    if byte != b' ' && byte != b'.' {
      return false;
    }
  }
}

/// `strncasecmp(name + from, want, want.len()) == 0`, `name` read as a C string.
fn starts_ci(name: &[u8], from: usize, want: &[u8]) -> bool {
  want
    .iter()
    .enumerate()
    .all(|(offset, byte)| at(name, from.saturating_add(offset)).to_ascii_lowercase() == byte.to_ascii_lowercase())
}

/// Format: the characters of an NTFS short name before its `~` (path.c, "shortened to 6 characters").
const SHORT_NAME_PREFIX: usize = 6;
/// Format: the characters of a whole 8.3 short name's base (path.c's loop `i < 8`).
const SHORT_NAME_BASE: usize = 8;

/// `is_ntfs_dot_generic`: `name` is `.` and `dotgit_name` either case, its 6-character short name with `~1` to `~4`,
/// or the fall-back short name whose first characters are `prefix` (8.3), each then only spaces and dots.
fn is_ntfs_dot(name: &[u8], dotgit_name: &[u8], prefix: &[u8; SHORT_NAME_PREFIX]) -> bool {
  if at(name, 0) == b'.' && starts_ci(name, 1, dotgit_name) {
    return only_spaces_and_dots(name, dotgit_name.len().saturating_add(1));
  }
  let short = dotgit_name.get(..SHORT_NAME_PREFIX).unwrap_or(dotgit_name);
  if starts_ci(name, 0, short)
    && at(name, SHORT_NAME_PREFIX) == b'~'
    && (b'1'..=b'4').contains(&at(name, SHORT_NAME_PREFIX.saturating_add(1)))
  {
    return only_spaces_and_dots(name, SHORT_NAME_PREFIX.saturating_add(2));
  }
  let mut saw_tilde = false;
  let mut index = 0;
  while index < SHORT_NAME_BASE {
    let byte = at(name, index);
    if byte == b'\0' {
      return false;
    } else if saw_tilde {
      if !byte.is_ascii_digit() {
        return false;
      }
    } else if byte == b'~' {
      index = index.saturating_add(1);
      if !(b'1'..=b'9').contains(&at(name, index)) {
        return false;
      }
      saw_tilde = true;
    } else if index >= SHORT_NAME_PREFIX
      || byte & 0x80 != 0
      || Some(&byte.to_ascii_lowercase()) != prefix.get(index)
    {
      return false;
    }
    index = index.saturating_add(1);
  }
  only_spaces_and_dots(name, index)
}

/// `.git` as HFS+ or NTFS reads it (`is_hfs_dotgit || is_ntfs_dotgit`).
pub(crate) fn dotgit(name: &[u8]) -> bool {
  is_hfs_dot(name, b"git") || is_ntfs_git(name)
}

/// `.git` as NTFS alone reads it, for the part of a name after a backslash.
pub(crate) fn ntfs_dotgit(name: &[u8]) -> bool {
  is_ntfs_git(name)
}

/// `.gitmodules` as HFS+ or NTFS reads it.
pub(crate) fn dotgitmodules(name: &[u8]) -> bool {
  is_hfs_dot(name, b"gitmodules") || ntfs_dotgitmodules(name)
}

/// `.gitmodules` as NTFS alone reads it, for the part of a name after a backslash.
pub(crate) fn ntfs_dotgitmodules(name: &[u8]) -> bool {
  is_ntfs_dot(name, b"gitmodules", b"gi7eba")
}

/// `.gitattributes` as HFS+ or NTFS reads it.
pub(crate) fn dotgitattributes(name: &[u8]) -> bool {
  is_hfs_dot(name, b"gitattributes") || is_ntfs_dot(name, b"gitattributes", b"gi7d29")
}

/// `.gitignore` as HFS+ or NTFS reads it.
pub(crate) fn dotgitignore(name: &[u8]) -> bool {
  is_hfs_dot(name, b"gitignore") || is_ntfs_dot(name, b"gitignore", b"gi250a")
}

/// `.mailmap` as HFS+ or NTFS reads it.
pub(crate) fn dotmailmap(name: &[u8]) -> bool {
  is_hfs_dot(name, b"mailmap") || is_ntfs_dot(name, b"mailmap", b"maba30")
}
