#!/usr/bin/env bash
# Makes slates-git's object golden vectors (A-590; §4.17.2 "Pieces (git)", piece 4): trees, commits and tags stock git
# wrote, in a SHA-1 and a SHA-256 repository, each well-formed one as git's own commands make it, and the malformed
# ones git's own t/t1450-fsck.sh makes (`git hash-object --literally`), with what stock `git fsck` says of each.
# Usage: make-objects.sh OUTDIR
# Writes, for each object, OUTDIR/<format>/<name> (its content, no header) and one line of OUTDIR/manifest.txt:
#   <format> <name> <type> <object id> <git fsck's message ids for it, comma-separated, in its order, or ->
#   <the first message id `git hash-object` (fsck, strict) refuses it with, or ->
# Deterministic: no configuration but this script's, a fixed identity, every date 2005-04-07T22:13:13Z.
#
# Sources: git v2.50.1's t/t1450-fsck.sh (each malformed object below names the test it comes from), fsck.c and fsck.h
# (the message ids), Documentation/gitformat-signature.txt (gpgsig, mergetag) and git-mktree, git-mktag, git-commit-tree.
set -euo pipefail
OUT=$(cd "$1" && pwd)
unset GIT_CONFIG_PARAMETERS GIT_DIR GIT_WORK_TREE
export GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_COUNT=0 TZ=UTC LC_ALL=C LANG=C
export GIT_AUTHOR_NAME='A U Thor' GIT_AUTHOR_EMAIL=author@example.com
export GIT_COMMITTER_NAME='C O Mitter' GIT_COMMITTER_EMAIL=committer@example.com
export GIT_AUTHOR_DATE='1112911993 +0000' GIT_COMMITTER_DATE='1112911993 +0000'
WORK=$(mktemp -d "$HOME/.cache/g225-objfix.XXXXXX")
trap 'rm -rf "$WORK"' EXIT
export HOME="$WORK/home"; mkdir -p "$HOME"
git --version > "$OUT/git-version.txt"
: > "$OUT/manifest.txt"

# Records object $3 of type $2 under name $1: its content, and git fsck's message ids for it.
keep() {
  local name=$1 type=$2 oid=$3
  git cat-file "$type" "$oid" > "$OUT/$FORMAT/$name"
  local ids
  ids=$(git fsck --no-dangling --no-progress --no-reflogs 2>&1 \
    | sed -E -n "s/^(error|warning) in $type $oid: ([a-zA-Z0-9]+):.*/\2/p" | paste -sd, - || true)
  # git fsck checks only what it could parse first; `git hash-object` without --literally checks every object with
  # fsck's own code (strict: a warning refuses too) and names the first finding.
  local strict
  strict=$(git cat-file "$type" "$oid" | git hash-object -t "$type" --stdin 2>&1 >/dev/null \
    | sed -E -n 's/^error: object fails fsck: ([a-zA-Z0-9]+):.*/\1/p' | head -1 || true)
  echo "$FORMAT $name $type $oid ${ids:--} ${strict:--}" >> "$OUT/manifest.txt"
}
lit() { git hash-object --literally -w -t "$1" --stdin; }
# Its input without its last byte (macOS's head takes no negative count).
drop_last() { local f; f=$(mktemp "$WORK/cut.XXXXXX"); cat > "$f"; head -c "$(( $(wc -c < "$f") - 1 ))" "$f"; }
hex2oct() { sed 's/\(..\)/\\x\1/g'; }

for FORMAT in sha1 sha256; do
  mkdir -p "$OUT/$FORMAT"
  rm -rf "$WORK/repo"; git init -q -b main --object-format=$FORMAT "$WORK/repo"; cd "$WORK/repo"
  git config core.protectNTFS false; git config core.protectHFS false
  ZERO=$(printf '%0*d' "$(git rev-parse --show-object-format=storage | sed 's/sha1/40/;s/sha256/64/')" 0)
  blob=$(echo blob | git hash-object -w --stdin)
  exec_blob=$(printf '#!/bin/sh\n' | git hash-object -w --stdin)
  link=$(printf 'target' | git hash-object -w --stdin)
  sub=$(printf 'a submodule commit\n' | git hash-object --stdin)   # not in the repository: a gitlink names another's commit
  # Well formed, as git's own commands write them: every mode git writes, and the order a directory's implied '/' makes.
  inner=$(printf '100644 blob %s\tfile\n' "$blob" | git mktree)
  tree=$( { printf '100644 blob %s\tlib-x\n' "$blob"; printf '100644 blob %s\tlib.rs\n' "$blob"
            printf '040000 tree %s\tlib\n' "$inner"; printf '100755 blob %s\trun\n' "$exec_blob"
            printf '120000 blob %s\tlink\n' "$link"; printf '160000 commit %s\tsub\n' "$sub"; } | git mktree --missing)
  keep ok-tree tree "$tree"
  keep ok-tree-empty tree "$(git mktree </dev/null)"
  root=$(echo 'first' | git commit-tree "$inner"); keep ok-commit-root commit "$root"
  side=$(echo 'side' | git commit-tree "$inner" -p "$root")
  merge=$(echo 'merge' | git commit-tree "$tree" -p "$root" -p "$side"); keep ok-commit-merge commit "$merge"
  enc=$(printf 'caf\xe9\n' | git -c i18n.commitEncoding=ISO-8859-1 commit-tree "$inner" -p "$root")
  keep ok-commit-encoding commit "$enc"
  # t1450 "commit with multiple signatures is okay": gpgsig and gpgsig-sha256, each with continuation lines.
  git cat-file commit "$root" > basis
  { sed -e '/^committer/q' basis
    printf 'gpgsig -----BEGIN PGP SIGNATURE-----\n  VGhpcyBpcyBub3QgcmVhbGx5IGEgc2lnbmF0dXJlLg==\n  -----END PGP SIGNATURE-----\n'
    printf 'gpgsig-sha256 -----BEGIN PGP SIGNATURE-----\n  VGhpcyBpcyBub3QgcmVhbGx5IGEgc2lnbmF0dXJlLg==\n  -----END PGP SIGNATURE-----\n'
    echo; sed -e '1,/^$/d' basis; } > signed
  keep ok-commit-gpgsig commit "$(git hash-object -t commit -w --stdin <signed)"
  # An annotated tag, and one whose message ends with a signature block (gitformat-signature).
  git update-ref refs/heads/main "$merge"
  git tag -a -m 'version one' v1 "$root"; keep ok-tag tag "$(git rev-parse v1)"
  { git cat-file tag v1; printf -- '-----BEGIN PGP SIGNATURE-----\n\nbm90IGEgc2lnbmF0dXJl\n-----END PGP SIGNATURE-----\n'; } > tag-signed
  signed_tag=$(git hash-object -t tag -w --stdin <tag-signed); keep ok-tag-signed tag "$signed_tag"
  # A merge of that tag: its mergetag header carries the whole tag, each line after the first a continuation.
  { sed -e '/^committer/q' <(git cat-file commit "$merge")
    printf 'mergetag '; sed -e '2,$s/^/ /' tag-signed; echo; echo 'merge tag v1'; } > merged
  keep ok-commit-mergetag commit "$(git hash-object -t commit -w --stdin <merged)"
  { sed -e '/^committer/q' basis; echo 'x-extra one value'; echo; sed -e '1,/^$/d' basis; } > extra
  keep ok-commit-extra commit "$(git hash-object -t commit -w --stdin <extra)"
  keep ok-commit-nomessage commit "$(sed -e '/^committer/q' basis | git hash-object -t commit -w --stdin)"

  # t1450's malformed commits, each named for its test.
  keep bad-email-gt commit "$(sed 's/@[a-z]/&>/' basis | lit commit)"          # email with embedded > is not okay
  keep bad-email-no-lt commit "$(sed 's/<//' basis | lit commit)"              # missing < email delimiter
  keep bad-email-missing commit "$(sed 's/[a-z]* <[^>]*>//' basis | lit commit)" # missing email
  keep bad-name-gt commit "$(sed 's/ </> </' basis | lit commit)"              # > in name is reported
  keep bad-date-overflow commit "$(sed 's/^\(author .*>\) [0-9]*/\1 18446744073709551617/' basis | lit commit)"
  keep bad-nul-header commit "$(sed 's/author ./author Q/' basis | tr Q '\000' | lit commit)"
  keep bad-multiple-authors commit "$(sed 's/^author .*/&,&/' basis | tr , '\n' | lit commit)"
  keep warn-nul-in-commit commit "$(printf 'initial commitQNUL after message\n' | git commit-tree "$inner" | xargs git cat-file commit | tr Q '\000' | lit commit)"
  # Each of fsck_commit's and fsck_ident's other refusals (fsck.c), one per object.
  keep bad-missing-tree commit "$(sed '1d' basis | lit commit)"
  keep bad-tree-sha1 commit "$(sed '1s/^tree ./tree z/' basis | lit commit)"
  keep bad-parent-sha1 commit "$(git cat-file commit "$enc" | sed 's/^parent ./parent z/' | lit commit)"
  keep bad-missing-author commit "$(sed '/^author /d' basis | lit commit)"
  keep bad-missing-committer commit "$(sed '/^committer /d' basis | lit commit)"
  keep bad-zero-padded-date commit "$(sed 's/^\(author .*>\) /\1 0/' basis | lit commit)"
  keep bad-timezone commit "$(sed 's/^\(author .*\) +0000$/\1 +000/' basis | lit commit)"
  keep bad-space-before-date commit "$(sed 's/^\(author .*>\) /\1/' basis | lit commit)"
  keep bad-name-before-email commit "$(sed 's/^author [^<]*/author /' basis | lit commit)"
  keep bad-space-before-email commit "$(sed 's/^\(author A U Thor\) /\1/' basis | lit commit)"
  keep bad-date commit "$(sed 's/^\(author .*>\) [0-9]*/\1 x/' basis | lit commit)"
  keep bad-unterminated-header commit "$(sed -e '/^committer/q' basis | drop_last | lit commit)"

  # t1450's malformed trees.
  e=$(git hash-object -w --stdin </dev/null)
  t=$(printf '100644 blob %s\tx\n' "$e" | git mktree)
  keep bad-tree-duplicate tree "$( (git cat-file tree "$t"; git cat-file tree "$t") | lit tree)"
  x2=$(printf '100644 blob %s\tx.2\n' "$blob" | git mktree)
  n=0; for names in 'x x.1 x/' 'x x.1.2 x.1/ x/' 'x x.1 x.1.2 x/'; do n=$((n + 1))
    keep "bad-tree-duplicate-names-$n" tree "$(for name in $names; do case $name in
      (*/) printf '040000 tree %s\t%s\n' "$x2" "${name%/}";; (*) printf '100644 blob %s\t%s\n' "$blob" "$name";; esac; done | git mktree)"
  done
  junk=$(printf '%s' twenty-bytes-of-junk-twelve-more | head -c "$(( ${#ZERO} / 2 ))")
  keep bad-tree-unparseable tree "$(printf "100644 \0$junk" | lit tree)"         # unparseable tree object
  keep info-tree-bogus-mode tree "$(printf "100000 foo\0$(echo "$blob" | hex2oct)" | lit tree)"
  keep warn-tree-null-blob tree "$(printf "100644 file\0$(echo "$ZERO" | hex2oct)" | lit tree)"
  keep warn-tree-null-gitlink tree "$(printf "160000 submodule\0$(echo "$ZERO" | hex2oct)" | lit tree)"
  long=$(printf 'n%.0s' $(seq 1 4097))
  keep warn-tree-large-name tree "$(printf "100644 $long\0$(echo "$blob" | hex2oct)" | lit tree)"
  n=0; while read -r path; do n=$((n + 1))
    keep "warn-tree-dot-$n" tree "$(printf '100644 blob %s\t%s' "$blob" "$path" | git mktree)"
    keep "warn-tree-dot-$n-dir" tree "$(printf '040000 tree %s\t%s' "$inner" "$path" | git mktree)"
  done <<-EOF
	.
	..
	.git
	.GIT
	.gI$(printf '\342\200\214')T
	.Git
	git~1
	.git.
	.\\.GIT\\foobar
	.git\\foobar
	EOF
  keep ok-tree-not-dotgit tree "$(printf '100644 blob %s\t.\305\207it' "$blob" | git mktree)"   # fsck allows .Ňit
  # Each of fsck_tree's other findings (fsck.c), one per object.
  keep warn-tree-zero-padded tree "$(printf "040000 dir\0$(echo "$inner" | hex2oct)" | lit tree)"
  keep warn-tree-full-path tree "$(printf "100644 a/b\0$(echo "$blob" | hex2oct)" | lit tree)"
  keep bad-tree-unsorted tree "$(printf "100644 b\0$(echo "$blob" | hex2oct)100644 a\0$(echo "$blob" | hex2oct)" | lit tree)"
  keep ok-tree-mode-664 tree "$(printf "100664 old\0$(echo "$blob" | hex2oct)" | lit tree)"
  keep bad-tree-gitmodules-symlink tree "$(printf "120000 .gitmodules\0$(echo "$link" | hex2oct)" | lit tree)"
  keep info-tree-gitignore-symlink tree "$(printf "120000 .gitignore\0$(echo "$link" | hex2oct)" | lit tree)"
  keep info-tree-gitattributes-symlink tree "$(printf "120000 .gitattributes\0$(echo "$link" | hex2oct)" | lit tree)"
  keep info-tree-mailmap-symlink tree "$(printf "120000 .mailmap\0$(echo "$link" | hex2oct)" | lit tree)"
  keep bad-tree-truncated tree "$(printf "100644 cut\0$(echo "$blob" | hex2oct)" | drop_last | lit tree)"

  # t1450's malformed tags.
  head=$root
  keep warn-tag-name-and-tagger tag "$(printf 'object %s\ntype commit\ntag wrong name format\n\nThis is an invalid tag.\n' "$head" | lit tag)"
  keep bad-tag-tagger tag "$(printf 'object %s\ntype commit\ntag not-quite-wrong\ntagger Bad Tagger Name\n\nThis is an invalid tag.\n' "$head" | lit tag)"
  keep bad-tag-nul-header tag "$(printf 'object %s\ntype commit\ntag contains-Q-in-header\ntagger T A Gger <tagger@example.com> 1234567890 -0000\n\nThis is an invalid tag.\n' "$head" | tr Q '\000' | lit tag)"
  # Each of fsck_tag_standalone's other findings (fsck.c), one per object.
  tg='tagger T A Gger <tagger@example.com> 1234567890 -0000'
  keep bad-tag-missing-object tag "$(printf 'type commit\ntag v\n%s\n\nm\n' "$tg" | lit tag)"
  keep bad-tag-object-sha1 tag "$(printf 'object zz\ntype commit\ntag v\n%s\n\nm\n' "$tg" | lit tag)"
  keep bad-tag-missing-type tag "$(printf 'object %s\ntag v\n%s\n\nm\n' "$head" "$tg" | lit tag)"
  keep bad-tag-type tag "$(printf 'object %s\ntype comet\ntag v\n%s\n\nm\n' "$head" "$tg" | lit tag)"
  keep bad-tag-missing-tag tag "$(printf 'object %s\ntype commit\n%s\n\nm\n' "$head" "$tg" | lit tag)"
  keep ignore-tag-extra-header tag "$(printf 'object %s\ntype commit\ntag v\n%s\nx-extra 1\n\nm\n' "$head" "$tg" | lit tag)"
  cd "$OUT"
done
( cd "$OUT" && shasum -a 256 manifest.txt sha1/* sha256/* > SHA256SUMS )
# The tests' table of the files, so each is compiled in and none is read at run time.
{ echo '// Generated by fixtures/make-objects.sh: each object file of manifest.txt, compiled in (A-590).'
  echo 'pub(crate) const FILES: &[(&str, &[u8])] = &['
  while read -r format name _; do
    printf '  ("%s/%s", include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/fixtures/objects/%s/%s"))),\n' \
      "$format" "$name" "$format" "$name"
  done < "$OUT/manifest.txt"
  echo '];'; } > "$OUT/table.rs"
